#!/usr/bin/env python3
import sys
import os
PACKAGE_PARENT = '..'
SCRIPT_DIR = os.path.dirname(os.path.realpath(os.path.join(os.getcwd(), os.path.expanduser(__file__))))
sys.path.append(os.path.normpath(os.path.join(SCRIPT_DIR, PACKAGE_PARENT)))

from flask import Flask, request
from werkzeug.exceptions import HTTPException

from model.nodes import get_nodes, get_node_by_name
from model.measurement import get_temperature, put_ft_measurement, get_humidity

from view.view import to_json

from model import db

app = Flask(__name__)

##### ********** Reading ********* ####
# _______ Get nodes _______ #
@app.route('/nodes/<int:node_id>', methods=['GET'])
def get_nodes_controller(node_id):
    res, status = get_nodes(node_id)

    return to_json(res), status

@app.route('/nodesByName/<string:node_name>', methods=['GET'])
def get_node_by_name_controller(node_name):
    res, status = get_node_by_name(node_name)

    return to_json(res), status

# _______ Get temperature _______ #
@app.route('/temperature/<int:node_id>', methods=['GET'])
def get_temperature_controller(node_id):
    date = request.args.get('date', '')
    sdate = request.args.get('sdate', '')
    edate = request.args.get('edate', '')

    res, status = get_temperature(node_id, sdate, edate)

    return to_json(res), status

# _______ Get humidity _______ #
@app.route('/humidity/<int:node_id>', methods=['GET'])
def get_humidity_controller(node_id):
    date = request.args.get('date', '')
    sdate = request.args.get('sdate', '')
    edate = request.args.get('edate', '')

    res, status = get_humidity(node_id, sdate, edate)

    return to_json(res), status

# _______ Measurements _______ #
@app.route('/put_ft_measurement/', methods=['POST'])
def put_ft_measurement_controller():
    print("Entro en el POST")
    res, status = put_ft_measurement(request)
    return to_json(res), status

##### ********** Aux ********* ####
@app.errorhandler(Exception)
def handle_error(e):
    db.session.rollback()
    code = 500
    if isinstance(e, HTTPException):
        code = e.code
    return to_json(error=str(e)), code


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5002)