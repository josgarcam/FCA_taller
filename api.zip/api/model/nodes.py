from model import db
from model.models import Nodes

def get_nodes(nodes_id):

    db.Base.metadata.create_all(db.engine)
    query = db.session.query(Nodes)
    print(nodes_id)

    query = query.filter(Nodes.nodes_id == nodes_id)
    objects = query.all()

    data = []
    for obj in objects:
        data.append({'node_id': obj.nodes_id,
                     'node_name': obj.nodes_name,
                     'node_desc': obj.nodes_desc,
                     'node_lat': obj.nodes_lat,
                     'node_alt': obj.nodes_alt})

    return data, 200


def get_node_by_name(node_name):

    db.Base.metadata.create_all(db.engine)
    query = db.session.query(Nodes)

    query = query.filter(Nodes.nodes_name == node_name)
    obj = query.first()

    if obj:
        data = {'node_id': obj.nodes_id,
                'node_name': obj.nodes_name,
                'node_desc': obj.nodes_desc,
                'node_lat': obj.nodes_lat,
                'node_alt': obj.nodes_alt}

        return data, 200

    else:
        return [], 200
