from model import db
from model.models import Measurement, FtTemperature, FtHumidity
from sqlalchemy import exc

def get_temperature(node_id, sdate, edate):
    db.Base.metadata.create_all(db.engine)
    query = db.session.query(Measurement, FtTemperature).join(FtTemperature, Measurement.mea_id == FtTemperature.ftTemp_meaId)
    query = query.filter(Measurement.mea_nodeId == node_id)

    if sdate or edate:
        query = query.order_by(Measurement.mea_date.desc())
        if sdate:
            query = query.filter(Measurement.mea_date >= sdate)
        if edate:
            query = query.filter(Measurement.mea_date <= edate)

    objects = query.all()

    data = []

    for obj in objects:

        data.append({'mea_id': obj.FtTemperature.ftTemp_meaId,
                     'mea_temp': obj.FtTemperature.ftTemp_temp,
                     'mea_date': obj.Measurement.mea_date
                    })

    return data, 200

def get_humidity(node_id, sdate, edate):
    db.Base.metadata.create_all(db.engine)
    query = db.session.query(Measurement, FtHumidity).join(FtHumidity, Measurement.mea_id == FtHumidity.ftHum_meaId)
    query = query.filter(Measurement.mea_nodeId == node_id)

    if sdate or edate:
        query = query.order_by(Measurement.mea_date.desc())
        if sdate:
            query = query.filter(Measurement.mea_date >= sdate)
        if edate:
            query = query.filter(Measurement.mea_date <= edate)

    objects = query.all()

    data = []

    for obj in objects:

        data.append({'mea_id': obj.FtHumidity.ftHum_meaId,
                     'mea_hum_gndOne': obj.FtHumidity.ftHum_gndOne,
                     'mea_hum_gndTwo': obj.FtHumidity.ftHum_gndTwo,
                     'mea_hum_air': obj.FtHumidity.ftHum_air,
                     'mea_date': obj.Measurement.mea_date
                    })

    return data, 200

def put_ft_measurement(request):
    db.Base.metadata.create_all(db.engine)
    data_dict = request.get_json()

    try:
        ob = Measurement(mea_nodeId=data_dict["mea_nodeId"],
                          mea_date=data_dict["mea_date"])

        print(data_dict["mea_date"])

        db.session.add(ob)
        db.session.commit()
        mea_id = ob.mea_id
        print(mea_id)

        ob_tem = FtTemperature(ftTemp_meaId=mea_id,
                               ftTemp_temp=data_dict["ftTemp_temp"])

        ob_hum = FtHumidity(ftHum_meaId=mea_id,
                            ftHum_gndOne=data_dict["ftHum_gndOne"],
                            ftHum_gndTwo=data_dict["ftHum_gndTwo"],
                            ftHum_air=data_dict["ftHum_air"])

        db.session.add(ob_tem)
        db.session.add(ob_hum)
        db.session.commit()

        return {"mea_id": mea_id, "ftTemp_id": ob_tem.ftTemp_id}, 200
        #return {"mea_id": mea_id, "tem_id": ob_tem.tem_id, "hum_id": ob_hum.hum_id}, 200

    except exc.IntegrityError as err:
        db.session.rollback()
        return str(err.orig), 400

    except KeyError as err:
        return f'Field not found:' + str(err), 400