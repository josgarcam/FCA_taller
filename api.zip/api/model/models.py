from model import db
from sqlalchemy import Column, Integer, String, Float, TIMESTAMP, BIGINT, ForeignKey


class Nodes(db.Base):
    __tablename__ = 'nodes'
    nodes_id = Column(Integer, primary_key=True)
    nodes_desc = Column(String)
    nodes_lat = Column(Float)
    nodes_alt = Column(Float)
    nodes_name = Column(String, unique=True)

class Measurement(db.Base):
    __tablename__ = 'measurement'
    mea_id = Column(BIGINT, primary_key=True)
    mea_date = Column(TIMESTAMP)
    mea_nodeId = Column(Integer, ForeignKey('nodes.nodes_id'))

class FtTemperature(db.Base):
    __tablename__ = 'ft_temperature'
    ftTemp_id = Column(BIGINT, primary_key=True)
    ftTemp_temp = Column(Float)
    ftTemp_meaId = Column(BIGINT, ForeignKey('measurement.mea_id'))

class FtHumidity(db.Base):
    __tablename__ = 'ft_humidity'
    ftHum_id = Column(BIGINT, primary_key=True)
    ftHum_gndOne = Column(Float)
    ftHum_gndTwo = Column(Float)
    ftHum_air = Column(Float)
    ftHum_meaId = Column(BIGINT, ForeignKey('measurement.mea_id'))

