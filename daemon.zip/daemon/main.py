from paho.mqtt import client as mqtt_client
from random import randrange
import logging
from json import loads
from base64 import b64decode
import requests

################# CONFIGURACIÓN #################

# Credenciales de acceso al broker TTS
credenciales_TTS = {
    "broker": "eu1.cloud.thethings.network",
    "port": 1883,
    "client_id": "python-daemon",
    "username": "loyola-node-tests@ttn",
    "password": "NNSXS.VTAT6Q2TDHARCHWZGB2SUUQB4B73DOI2L2TRZ5Y.BV7PSIYCAVDG5A6UNWSWW4I7OARMWWNIIEH5ZCW4Z3MKCMRRTR7Q",
    "topic": ["v3/loyola-node-tests@ttn/devices/+/up", 0]
}

# Conexión a la API
api_host = "localhost"
api_port = 5002

logging.basicConfig(level=logging.DEBUG,
                    format='%(asctime)s - %(threadName)s -> %(module)s -> %(funcName)s (%(lineno)s) : %(levelname)s : %(message)s')
#################################################


def desescalado_temperatura(x):
    return x * 165/255 - 40


def desescalado_humedad(x):
    return (x - 26.66919) / 231.0817


def on_connect(client, userdata, flags, rc):
    """ Función a ejecutar cuando el cliente se conecta al bróker MQTT"""
    if rc == 0:
        logging.info(f"Client {client._client_id.decode()} connected to MQTT Broker")
        # Suscripción a los topìcs indicados
        client.subscribe(tuple(userdata["topic"]))
        return True
    else:
        logging.error(f"Client {client._client_id.decode()} failed to connect, code {rc}")
        raise


def on_message(client, userdata, msg):
    """ Función a ejecutar cuando el cliente recibe un nuevo mensaje"""
    try:
        logging.info(f"{client._client_id.decode()} New message")
        msg = loads(msg.payload.decode())
        node_name = msg["end_device_ids"]["device_id"]
        timestamp = msg["received_at"]
        payload_b64 = msg["uplink_message"]["frm_payload"]
        payload = iter(b64decode(payload_b64, validate=True))

        datos = {"mea_date": timestamp,
                 "ftTemp_temp": desescalado_temperatura(next(payload)),
                 "ftHum_gndOne": desescalado_humedad(next(payload)),
                 "ftHum_gndTwo": desescalado_humedad(next(payload)),
                 "ftHum_air": desescalado_humedad(next(payload))}

        logging.info(f"{client._client_id.decode()} Contenido del mensaje: node_name: {node_name}, timestamp: {timestamp}, nodetemperatura_aire: {datos['ftTemp_temp']}, humedad_suelo_1: {datos['ftHum_gndOne']}, humedad_suelo_2: {datos['ftHum_gndTwo']}, humedad_aire: {datos['ftHum_air']}")

        res = requests.get(f"http://{userdata['api_host']}:{userdata['api_port']}/nodesByName/{node_name}").json()
        logging.info(f"Id del nodo remitente: {res['node_id']}")
        datos.update({"mea_nodeId": res["node_id"]})
        res = requests.post(f"http://{userdata['api_host']}:{userdata['api_port']}/put_ft_measurement/", json=datos)

        if res.ok:
            logging.info("Mensaje enviado con éxito")
        else:
            logging.warning("Error enviando el mensaje")

    except:
        logging.warning("Error procesando el mensaje")


# Configuración del cliente paho
cliente = mqtt_client.Client(client_id=credenciales_TTS["client_id"] + '_' + str(randrange(9999)), clean_session=False)
cliente.username_pw_set(username=credenciales_TTS["username"], password=credenciales_TTS["password"])
cliente.user_data_set({"topic": credenciales_TTS["topic"], "api_host": api_host, "api_port": api_port})
cliente.on_connect = on_connect
cliente.on_message = on_message
cliente.connect(credenciales_TTS['broker'], port=credenciales_TTS["port"])

# Lanzar cliente
cliente.loop_forever()

